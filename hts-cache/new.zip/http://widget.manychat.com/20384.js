window.mcwidget = {"appId":"532160876956612","pageId":"20384","page_name":"MarketPresso","fb_page_id":"108939750669751","widget_phone":null,"widgets":[{"widget_id":9192452,"page_id":"20384","widget_type":"customer_chat","status":"active","name":"Growth Tool #4","data":{"feed_comment_settings":[],"setup":{"urlWhitelist":["https://marketpresso.com/special/","https://marketpresso.com/live","https://marketpresso.com/pro","https://marketpresso.com/proninja","https://marketpresso.com/club","https://marketpresso.com/clubninja","https://marketpresso.com/agency","https://marketpresso.com/agencyninja","https://marketpresso.com/mobileapp/","https://marketpresso.com/mobileappninja/","https://www.marketpresso.com/special/","https://www.marketpresso.com/live","https://www.marketpresso.com/pro","https://www.marketpresso.com/proninja","https://www.marketpresso.com/club","https://www.marketpresso.com/clubninja","https://www.marketpresso.com/agency","https://www.marketpresso.com/agencyninja","https://www.marketpresso.com/mobileapp/","https://www.marketpresso.com/mobileappninja/"],"loggedInGreeting":"Hi! How can we help you?","loggedOutGreeting":"Hi! How can we help you?","minimized":"hidden"}},"channel":"facebook","ts_created":1580638619,"chat_ref":"w9192452"},{"widget_id":9192436,"page_id":"20384","widget_type":"landing","status":"active","name":"Example Landing","data":[],"channel":"facebook","ts_created":1580638535}],"widgetLocale":"en_US","defaultSize":0,"fbSDKVersion":"v7.0","whitelist":["e04a45f0a505569fddc714decd22a84e8cb421b628b371dd70f2ca7035eac346","f2cbfeda670dc91d10651057f2d9c1f9010175cf28059cfc43337b7d2c6f3f4d","8c1342e74b3c6a256447440ffa382ca6b5c4c8ce89d9b102e4d25a8e1ba6bf31","a3a8a97477aa138b1310ae6580db609a28abb4861a0d35f6f03f78de459389da"],"smsModalConsentText":"Please note that by typing in your phone number in the field above you are agreeing to receive autodialed personal and marketing text messages to your mobile number. Consent is not required for purchase. Message and data rates may apply. Reply “STOP” by SMS to cancel."};


    (function(d, s, id){
        var host = 'mccdn.me/130340';

        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) { return; }
        js = d.createElement(s); js.id = id;
        js.src = '//' + host + '/assets/js/widget.js';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'mcwidget-core'));

            